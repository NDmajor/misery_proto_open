package com.contract.backend.common.repository;

import com.contract.backend.common.Entity.ContractEntity;
import com.contract.backend.common.Entity.ContractPartyEntity;
import com.contract.backend.common.Entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ContractPartyRepository extends JpaRepository<ContractPartyEntity, Long> {
    List<ContractPartyEntity> findByContract(ContractEntity contract);
    List<ContractPartyEntity> findByParty(UserEntity party);
    Optional<ContractPartyEntity> findByContractAndParty(ContractEntity contract, UserEntity party);
    List<ContractPartyEntity> findAllByParty(UserEntity party); // 특정 사용자가 참여한 모든 계약 당사자 정보 조회
}
