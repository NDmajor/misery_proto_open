const colors = {
  text: '#202124',

  grey: '#5f6368',
  grey100: '#3c4043',
  primary: '#1967d2',
  primarySvg: '#4285f4',
  primary100: '#e8f0fe',
  primaryIndicator: '#1a73e8',

  onWhite: '#f1f3f4',
  divider: '#dadce0',
}

export default colors
