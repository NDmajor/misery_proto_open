const shadows = {
  searchResults:
    '0 1px 1px 0 rgb(65 69 73 / 30%), 0 1px 3px 1px rgb(65 69 73 /15%)',
}

export default shadows
