package com.contract.backend.common.Entity.enumm;

public enum PartyRole {
    INITIATOR,
    COUNTERPARTY
}
