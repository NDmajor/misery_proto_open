package com.contract.backend.common.Entity.enumm;

public enum ContractStatus {
    OPEN,
    CLOSED,
    CANCELLED
}
