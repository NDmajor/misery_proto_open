package com.contract.backend.common.Entity.enumm;

public enum VersionStatus {
    PENDING_SIGNATURE,
    SIGNED,
    ARCHIVED
}
